export type ImageArrayType = Array<{
	description: string;
	group: string;
	title: string;
	url: string;
}>;
