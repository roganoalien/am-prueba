export type TitleType = {
	title: string;
};
